<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'sanskrati');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Y:B[4HXn5s7QlxZ4554/h;pp8/u9.#ppsFe7Z$;?T4;w%-RB}v@Up30+yry)quNk');
define('SECURE_AUTH_KEY',  's*teTeNeuQ#Wo4i6KVuzYH-2!en<)kAnzM!=cDm%1#XOq,/S1D_WmBOn3bX3G@Pr');
define('LOGGED_IN_KEY',    'Z:;Ox7}:xh_uc`d.Y;FoRH(`m[qMedN@wD?9o8~O}hw <yv`IAK.PyEnlwn+]?}(');
define('NONCE_KEY',        'X%4hrlTX=5SKRiZ9|xzl~pkv@!8%Af>]V7vzekNxo$O16J[(g/`CIkbu,a3Lp,BO');
define('AUTH_SALT',        '~1?B,9t.K3WVrcH9#6Z;&hh@ 1r>SRQ7R>Zt76)t*hL443U0{GYY|^~+c?^0C(B-');
define('SECURE_AUTH_SALT', 'x7r`fH2?VV!.93/(!lKCVc?yS uyW0I1#a18@}&XCj_J8YidLCPY:9J|>fd6C@-U');
define('LOGGED_IN_SALT',   '8R-f]=dt~k4aq0<=E8QZdD>/iX:rXC:,KG{gB=4J-D`dr063fgRVfquw~^hs7WOs');
define('NONCE_SALT',       'O-lTU3~-WUtY5XMVma#ER[-H1]a6F]/EK|Ma4v~.W]@Wb)Huwq+D%si@^)64E1dt');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
